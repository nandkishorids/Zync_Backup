<?xml version="1.0" encoding="utf-8"?>
<xsl:stylesheet version="1.0"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

	<xsl:output method="xml" indent="yes"/>

	<xsl:param name="BankAccount"/>
	<xsl:param name="SetPaymentInfo"/>
	<xsl:param name="SetAccountRefNumber"/>

	<xsl:template match="ArrayOfSalesOrder">
		<Company>
			<SalesOrders>
				<xsl:for-each select="SalesOrder">
					<xsl:call-template name="SalesOrder" />
				</xsl:for-each>
			</SalesOrders>
		</Company>
	</xsl:template>

	<xsl:template name="SalesOrder">
		<SalesOrder>
			<Id></Id>
			<CustomerId>
				<xsl:value-of select="customer_id"/>
			</CustomerId>
			<AccountReference>
				<xsl:value-of select="$SetAccountRefNumber"/>
			</AccountReference>
			<DefaultWarehouse>ROTHERHAM</DefaultWarehouse>
			<!-- <SalesOrderNumber><xsl:value-of select="increment_id"/></SalesOrderNumber> -->
			<xsl:if test="extension_attributes/CustomValues/CustomValue[@Name = 'date_promised'] != ''">
				<PromisedDeliveryDate>
					<xsl:value-of select="extension_attributes/CustomValues/CustomValue[@Name = 'date_promised']"/>
				</PromisedDeliveryDate>
			</xsl:if>
			<CustomerOrderNumber>
				<xsl:value-of select="$SetAccountRefNumber"/>-<xsl:value-of select="increment_id"/>
			</CustomerOrderNumber>
			<SalesOrderDate>
				<xsl:value-of select="created_at"/>
			</SalesOrderDate>
			<SalesOrderAddress>
				<!--<Title><xsl:value-of select="billing_address/firstname"/></Title>-->
				<Forename>
					<xsl:value-of select="billing_address/firstname"/>
				</Forename>
				<Surname>
					<xsl:value-of select="billing_address/lastname"/>
				</Surname>
				<Company>
					<xsl:value-of select="billing_address/company"/>
				</Company>			
				<Address1>
					<xsl:value-of select="billing_address/street/string"/>
				</Address1>
				<Town>
					<xsl:value-of select="billing_address/city"/>
				</Town>
				<Postcode>
					<xsl:value-of select="billing_address/postcode"/>
				</Postcode>
				<County>
					<xsl:value-of select="billing_address/region"/>
				</County>
				<Country>
					<xsl:value-of select="billing_address/country_id"/>
				</Country>
				<Telephone>
					<xsl:value-of select="billing_address/telephone"/>
				</Telephone>
				<Email>
					<xsl:value-of select="customer_email"/>
				</Email>
			</SalesOrderAddress>
			<SalesOrderDeliveryAddress>
				<!--<Title><xsl:value-of select="shipping_address/firstname"/></Title>-->
				<Forename>
					<xsl:value-of select="extension_attributes/shipping_assignments/shipping_assignment/shipping/address/firstname"/>
				</Forename>
				<Surname>
					<xsl:value-of select="extension_attributes/shipping_assignments/shipping_assignment/shipping/address/lastname"/>
				</Surname>
				<Company>
					<xsl:value-of select="extension_attributes/shipping_assignments/shipping_assignment/shipping/address/company"/>
				</Company>
				<Address1>
					<xsl:value-of select="extension_attributes/shipping_assignments/shipping_assignment/shipping/address/street/string"/>
				</Address1>
				<Town>
					<xsl:value-of select="extension_attributes/shipping_assignments/shipping_assignment/shipping/address/city"/>
				</Town>
				<Postcode>
					<xsl:value-of select="extension_attributes/shipping_assignments/shipping_assignment/shipping/address/postcode"/>
				</Postcode>
				<County>
					<xsl:value-of select="extension_attributes/shipping_assignments/shipping_assignment/shipping/address/region"/>
				</County>
				<Country>
					<xsl:value-of select="extension_attributes/shipping_assignments/shipping_assignment/shipping/address/country_id"/>
				</Country>
				<Telephone>
					<xsl:value-of select="extension_attributes/shipping_assignments/shipping_assignment/shipping/address/telephone"/>
				</Telephone>
				<Email>
					<xsl:value-of select="customer_email"/>
				</Email>
			</SalesOrderDeliveryAddress>
			<xsl:variable name="shippingCountry" select="extension_attributes/shipping_assignments/shipping_assignment/shipping/address/country_id" />
			<SalesOrderItems>
				<xsl:for-each select="items/item[product_type != 'configurable']">
					<xsl:call-template name="Item">
						<xsl:with-param name="shippingCountry" select="$shippingCountry" />
					</xsl:call-template>
				</xsl:for-each>
				<xsl:if test="shipping_amount != 0">
					<Item>
						<Type>ChargeLine</Type>
						<xsl:if test="contains(extension_attributes/CustomValues/CustomValue[@Name = 'instructions'], 'Pallet')">
							<Sku>Carriage</Sku>
						</xsl:if>
						<xsl:if test="contains(extension_attributes/CustomValues/CustomValue[@Name = 'instructions'], 'DPD')">
							<Sku>Tapspares Delivery</Sku>
						</xsl:if>
						<Name><xsl:value-of select="extension_attributes/CustomValues/CustomValue[@Name = 'instructions']"/></Name>
						<QtyOrdered>1</QtyOrdered>
						<UnitPrice>
							<xsl:value-of select="shipping_amount" />
						</UnitPrice>
						<UnitDiscountAmount>
							<xsl:value-of select="shipping_discount_amount"/>
						</UnitDiscountAmount>
						<TotalTax>
							<xsl:value-of select="shipping_tax_amount" />
						</TotalTax>
					</Item>
				</xsl:if>
				<!--<Item>
					<Type>FreeText</Type>
					<Text>Adobe Commerce Order - <xsl:value-of select="increment_id"/>
					</Text>
					<Description>Adobe Commerce Order - <xsl:value-of select="increment_id"/>
					</Description>
					<QtyOrdered>1</QtyOrdered>
					<UnitPrice>0</UnitPrice>
					<UnitDiscountAmount>0</UnitDiscountAmount>
					<TotalTax>0</TotalTax>
				</Item>-->
			</SalesOrderItems>
			<TakenBy>Website</TakenBy>
			<xsl:if test="$SetPaymentInfo = 'true'">
				<!--<xsl:if test="payment/amount_paid != ''">-->
				<xsl:choose>
					<xsl:when test="payment/method = 'braintree' and contains(payment/additional_information, 'Credit / Debit Card')">
						<PaymentRef>Abodedesigns Sagepay</PaymentRef>
					</xsl:when>
					<xsl:when test="payment/method = 'braintree_googlepay'">
						<PaymentRef>Abodedesigns Google</PaymentRef>
					</xsl:when>
					<xsl:when test="payment/method = 'braintree_applepay'">
						<PaymentRef>Abodedesigns Apple</PaymentRef>
					</xsl:when>
					<xsl:when test="payment/method = 'paypal_express'">
						<PaymentRef>Abodedesigns Paypal</PaymentRef>
					</xsl:when>
					<xsl:when test="payment/method = 'klarna_kp' and contains(payment/additional_information, 'klarna_pay_over_time')">
						<PaymentRef>Abodedesigns KlarnaS</PaymentRef>
					</xsl:when>
					<xsl:when test="payment/method = 'klarna_kp' and contains(payment/additional_information, 'Pay in 30 days')">
						<PaymentRef>Abodedesigns Klarna</PaymentRef>
					</xsl:when>
					<xsl:when test="payment/method = 'checkmo'">
						<PaymentRef>Abodedesigns Paypal</PaymentRef>
					</xsl:when>
					<xsl:otherwise>
						<PaymentRef>Abodedesigns Paypal</PaymentRef>
					</xsl:otherwise>
				</xsl:choose>
				<PaymentAmount>
				    <xsl:choose>
								<xsl:when test="payment/amount_paid != ''">
										<xsl:value-of select="payment/amount_paid"/>
								</xsl:when>
								<xsl:otherwise>
										<xsl:value-of select="payment/amount_ordered"/>
								</xsl:otherwise>
						</xsl:choose>
				</PaymentAmount>
				<BankAccount>
					<xsl:value-of select="$BankAccount"/>
				</BankAccount>
				<!--</xsl:if>-->
			</xsl:if>
			<TaxCode>1</TaxCode>
		</SalesOrder>
	</xsl:template>

	<xsl:template name="Item">
		<xsl:param name="shippingCountry" />
		<Item>
			<Sku>
				<xsl:value-of select="substring(translate(sku, ' ', '-'), 1, 30)" />
			</Sku>
			<Name>
				<xsl:value-of select="name" />
			</Name>
			<QtyOrdered>
				<xsl:value-of select="qty_ordered" />
			</QtyOrdered>
			<UnitPrice>
				<xsl:choose>
					<!-- May need to take the price from the configurable product -->
					<xsl:when test="price = 0 and parent_item and parent_item/sku = sku and parent_item/product_type = 'configurable'">
						<xsl:value-of select="parent_item/price" />
					</xsl:when>
					<xsl:otherwise>
						<xsl:value-of select="price" />
					</xsl:otherwise>
				</xsl:choose>
			</UnitPrice>
			<TaxCode>1</TaxCode>
			<!--<UnitDiscountAmount><xsl:value-of select="discount_amount"/></UnitDiscountAmount>-->
			<UnitDiscountPercentage>
				<xsl:choose>
					<!-- May need to take the price from the configurable product -->
					<xsl:when test="price = 0 and parent_item and parent_item/sku = sku and parent_item/product_type = 'configurable'">
						<xsl:value-of select="parent_item/discount_percent" />
					</xsl:when>
					<xsl:otherwise>
						<xsl:value-of select="discount_percent"/>
					</xsl:otherwise>
				</xsl:choose>
			</UnitDiscountPercentage>
			<Location>ROTHERHAM</Location>
		</Item>
	</xsl:template>
</xsl:stylesheet>